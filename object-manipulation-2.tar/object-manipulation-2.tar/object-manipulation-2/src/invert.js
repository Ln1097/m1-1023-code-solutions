/* exported invert */
