/* exported takeRight */
