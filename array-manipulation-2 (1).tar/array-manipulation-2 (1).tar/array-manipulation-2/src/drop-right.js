/* exported dropRight */
