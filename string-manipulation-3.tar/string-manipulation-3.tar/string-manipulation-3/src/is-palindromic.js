/* exported isPalindromic */
