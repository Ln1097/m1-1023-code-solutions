/* exported isAnagram */
