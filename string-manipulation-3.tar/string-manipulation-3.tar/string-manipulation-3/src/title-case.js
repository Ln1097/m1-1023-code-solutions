/* exported titleCase */
