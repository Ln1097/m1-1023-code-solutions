console.log('Lodash is loaded:', typeof _ !== 'undefined');
