/* exported intersection */
