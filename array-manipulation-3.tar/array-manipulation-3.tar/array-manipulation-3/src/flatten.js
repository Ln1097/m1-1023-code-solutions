/* exported flatten */
